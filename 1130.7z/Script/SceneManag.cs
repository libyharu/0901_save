using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.IO;


public class SceneManag : MonoBehaviour
{
    //�⺻
    public GameObject menu, login, profile, balance, rehabilitation, selectGame, Mode, characterSelect,LougoutPopup;

    //���Ӽ���
    public GameObject ingame, walkgame, modelgame;
    public GameObject popup, walkpop, modelpop;

    //ĳ���� �� ī�޶�
    public GameObject trampoline, dog;
    public GameObject WalkCamera, ModelCamera, RehabillCamera;

    //levle
    public int level;

    public GameObject gm;
    private SaveData_Game gameData = new SaveData_Game();
    private SaveData_Info infoData = new SaveData_Info();
    public Animator reha;

    //�޴� 
    public void MenuPage(int i)
    {
        if (menu.activeSelf == true)
        {
            menu.SetActive(false);
        }

        switch (i)
        {
            case 0:
                selectGame.SetActive(true);
                break;

            case 1:
                profile.SetActive(true);
                break;

            case 2:
                rehabilitation.SetActive(true);
                ingame = rehabilitation;
                break;

            case 3:
                LougoutPopup.SetActive(true);
                break;

            case 4:
                Debug.Log("�м�");
                menu.SetActive(true);
                break;

            case 5:
                balance.SetActive(true);
                break;
        }

    }

    public void logoutPanelNo()
    {
        LougoutPopup.SetActive(false);
        menu.SetActive(true);
    }

    public void logoutPanelOk()
    {
        login.SetActive(true);
        LougoutPopup.SetActive(false);
    }

    void menuopen()
    {
        login.SetActive(false);
        profile.SetActive(false);
        balance.SetActive(false);
        rehabilitation.SetActive(false);
        selectGame.SetActive(false);
    }

    //

    //��ü �ڷΰ���
    public void Back(int t)
    {
        switch (t)
        {
            case 0: //profile
                profile.SetActive(false);
                menu.SetActive(true);
                break;

            case 1: //balance
                balance.SetActive(false);
                menu.SetActive(true);
                break;

            case 2: // rehabilitation
                rehabilitation.SetActive(false);
                menu.SetActive(true);
                reha.speed = 1f;
                break;

            case 3: //selectGame
                selectGame.SetActive(false);
                menu.SetActive(true);
                break;


            case 4: //mode
                load();
                Mode.SetActive(false);
                save();
                break;

            case 5: //character
                characterSelect.SetActive(false);
                save();
                break;

            case 6:
                selectGame.SetActive(true);
                Mode.SetActive(true);
                characterSelect.SetActive(true);
                break;
        }
    }

    //�α���
    public void LoginPage()
    {        
        //null check �� �ε�
        load();
        if (infoData.login)
        {
            login.SetActive(false);
            menu.SetActive(true);
        }
    }

    //������
    public void ProfilePage()
    {
        load();

        if (infoData.profile)
        {
            profile.SetActive(false);
            menu.SetActive(true);
        }
    }

    //���� ����
    public void SelGamePage(int j)
    {

        switch (j)
        {
            case 0:
                load();
                Mode.SetActive(true);
                ingame = null;
                ingame = walkgame;
                gameData.ingameName.Add(walkgame.name);

                popup = null;                popup = walkpop;
                gameData.popupName.Add(popup.name);
                break;

            case 1:
                load();
                Mode.SetActive(true);
                ingame = null;
                ingame = modelgame;
                gameData.ingameName.Add(modelgame.name);

                popup = null;
                popup = modelpop;
                gameData.popupName.Add(popup.name);
                break;
        }

        save();
    }

    //���̵� ����
    public void ModePage(int i)
    {
        characterSelect.SetActive(true);
        load();
        switch (i)
        {
            case 0:
                if (ingame == walkgame)
                {
                    level = 1;
                    gameData.level_walk.Add(level);
                }
                if(ingame == modelgame)
                {
                    level = 1;
                    gameData.level_model.Add(level);
                }

                save();
                break;

            case 1:
                if (ingame == walkgame)
                {
                    level = 2;
                    gameData.level_walk.Add(level);
                }
                if (ingame == modelgame)
                {
                    level = 2;
                    gameData.level_model.Add(level);
                }
                save();
                break;

            case 2:
                if (ingame == walkgame)
                {
                    level = 3;
                    gameData.level_walk.Add(level);
                }
                if (ingame == modelgame)
                {
                    level = 3;
                    gameData.level_model.Add(level);
                }
                save();
                break;
        }
    }

    //ĳ���� ����
    public void SelCharacter()
    {
        if (ingame.name == "In Game Walk")
        {
            //SceneManager.LoadScene("Test");
            SceneManager.LoadScene("walk");
            gameData.isScene = true;

            DontDestroyOnLoad(gm);
        }


        if (ingame.name == "In Game Model")
        {
            modelgame.SetActive(true);
            trampoline.SetActive(true);
        }
    }

    private void Start()
    {
        load();
        if (gameData.isScene == true)
        {
            if (!selectGame.activeSelf)
            {
                menu.SetActive(false);
                selectGame.SetActive(true);
            }
        }
    }

    void save()
    {
        // ���� ��ü ����
        string json = JsonUtility.ToJson(infoData); // ���̽�ȭ
        File.WriteAllText(Application.dataPath + "/Resources/infoData.json", json);

        string gameJs = JsonUtility.ToJson(gameData);
        File.WriteAllText(Application.dataPath + "/Resources/gameData.json", gameJs);

    }

    private string loadJson, ingameName, loadgame;
    void load()
    {
        //ingame load
        loadJson = File.ReadAllText(Application.dataPath + "/Resources/infoData.json");
        infoData = JsonUtility.FromJson<SaveData_Info>(loadJson);

        loadgame = File.ReadAllText(Application.dataPath + "/Resources/gameData.json");
        gameData = JsonUtility.FromJson<SaveData_Game>(loadgame);

        #region  //ingame
        for (int i = 0; i < gameData.ingameName.Count; i++)
        {
            if(gameData.ingameName.Count != 1)
            {
                i = gameData.ingameName.Count-1;
                
                if (gameData.ingameName[i] == "In Game Walk")
                {
                    ingameName = gameData.ingameName[i];
                }

                if (gameData.ingameName[i] == "In Game Model")
                {
                    ingameName = gameData.ingameName[i];
                }
            }

            else
            {
                if (gameData.ingameName[i] == "In Game Walk")
                {
                    ingameName = gameData.ingameName[i];
                }

                if (gameData.ingameName[i] == "In Game Model")
                {
                    ingameName = gameData.ingameName[i];
                }
            }
        }
        #endregion

        #region //mode 
        if (ingame == walkgame)
        {
            for (int i = 0; i < gameData.level_walk.Count; i++)
            {
                if (gameData.level_walk.Count != 1)
                {
                    i = gameData.level_walk.Count;
                }
                else
                {
                    level = gameData.level_walk[i];
                }
            }
        }

        if(ingame == modelgame)
        {
            for (int i = 0; i < gameData.level_model.Count; i++)
            {
                if (gameData.level_model.Count != 1)
                {
                    i = gameData.level_model.Count;
                }
                else
                {
                    level = gameData.level_model[i];
                }
            }
        }
        #endregion

    }

    void Update()
    {
        if (menu.activeSelf == true)
        {
            menuopen();
        }
       
    }
}
