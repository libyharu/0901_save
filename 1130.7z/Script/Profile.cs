using UnityEngine;
using UnityEngine.UI;
using System.Text.RegularExpressions;
using System.IO;
using System.Collections.Generic;

public class Profile : MonoBehaviour
{
    public InputField IFgender, IFage, IFheight, IFweight, IFdoctor, IFetc;
    private InputField ip;

    public Text guideTxt;

    private string guide;
    private SaveData_Info infoData = new SaveData_Info();

    private List<InputField> list;
    private int curPos;

    void Start()
    {
        Regex.IsMatch(guideTxt.text, "^[0-9a-zA-Z��-�R]*$");
        list = new List<InputField>();
        Add();
    }

    //Focus �� InputField�� �����Ѵ�.
    //�𸣰���
    #region
    //private void SetFocus(int idx = 0)
    //{
    //    if (idx >= 0 && idx < list.Count)
    //    {
    //        list[idx].Select();
    //    }
    //}
    #endregion


    private void Add()
    {
        list.Add(IFgender);
        list.Add(IFage);
        list.Add(IFheight);
        list.Add(IFweight);
        list.Add(IFdoctor);
        list.Add(IFetc);
    }


    //���� ��ġ Ȯ��
    private int GetCurerntPos()
    {
        for (int i = 0; i < list.Count; ++i)
        {
            if (list[i].isFocused == true)
            {
                curPos = i;
                break;
            }
        }
        return curPos;
    }

    private void MoveNext()
    {
        GetCurerntPos();
        if (curPos < list.Count - 1)
        {
            ++curPos;
            list[curPos].Select();
        }
    }

    private void MovePrev()
    {
        GetCurerntPos();
        if (curPos > 0)
        {
            --curPos;
            list[curPos].Select();
        }
    }

    private void OnGUI()
    {
        Event e = Event.current;
        if (e.isKey)
        {
            if (Input.GetKeyDown(KeyCode.Tab) && !Input.GetKey(KeyCode.LeftShift))
            {
                MoveNext();
            }
            if (Input.GetKey(KeyCode.LeftShift) && Input.GetKeyDown(KeyCode.Tab))
            {
                MovePrev();
            }
        }
    }

    //���� �Է��� ������ Ȯ��
    public void Function_InputField()
    {
        ip = IFgender;
        infoData.gender.Add(ip.text);

        ip = IFage;
        infoData.age.Add(ip.text);

        ip = IFheight;
        infoData.height.Add(ip.text);

        ip = IFweight;
        infoData.weight.Add(ip.text);

        ip = IFdoctor;
        infoData.doctor.Add(ip.text);

        ip = IFetc;
        infoData.etc.Add(ip.text);

        save();
    }

    void save()
    {
        // info
        string json = JsonUtility.ToJson(infoData); // ���̽�ȭ
        File.WriteAllText(Application.dataPath + "/Resources/infoData.json", json);
    }


    private string loadJson;

    void load()
    {
        //info
        loadJson = File.ReadAllText(Application.dataPath + "/Resources/infoData.json");
        infoData = JsonUtility.FromJson<SaveData_Info>(loadJson);
    }

    public void open()
    {
        load();
        infoData.profile = false;
        Function_InputField();

        for (int i = 0; i < infoData.gender.Count; i++)
        {
            if (infoData.gender.Count != 1)
            {

                i = infoData.gender.Count - 1;
                IFgender.text = infoData.gender[i];
            }
            else
            {
                IFgender.text = infoData.gender[i];
            }
        }

        for (int i = 0; i < infoData.age.Count; i++)
        {
            if(infoData.age.Count != 1)
            {
                i = infoData.age.Count - 1;
                IFage.text = infoData.age[i];
            }
            else
            {
                IFage.text = infoData.age[i];
            }
        }

        for (int i = 0; i < infoData.height.Count; i++)
        {
            if(infoData.height.Count != 1)
            {
                i = infoData.height.Count - 1;
                IFheight.text = infoData.height[i];
            }
            else
            {
                IFheight.text = infoData.height[i];
            }
        }

        for (int i = 0; i < infoData.weight.Count; i++)
        {
            if(infoData.weight.Count != 1)
            {
                i = infoData.weight.Count - 1;
                IFweight.text = infoData.weight[i];
            }
            else
            {
                IFweight.text = infoData.weight[i];
            }
        }

        for (int i = 0; i < infoData.doctor.Count; i++)
        {
            if(infoData.doctor.Count != 1)
            {
                i = infoData.doctor.Count - 1;
                IFdoctor.text = infoData.doctor[i];
            }
            else
            {
                IFdoctor.text = infoData.doctor[i];
            }
        }

        for (int i = 0; i < infoData.etc.Count; i++)
        {
            if (infoData.etc.Count != 1)
            {
                i = infoData.doctor.Count - 1;
                IFetc.text = infoData.etc[i];
            }
            else
            {
                IFetc.text = infoData.etc[i];
            }
        }
    }

    public void Nullsave()
    {
       
        if (string.IsNullOrEmpty(IFgender.text))
        {
            guide = "������ �Է��� �ּ���.";
            guideTxt.text = guide;
        }

        else if (string.IsNullOrEmpty(IFage.text))
        {
            guide = "������ �Է��� �ּ���.";
            guideTxt.text = guide;
        }
        else if (string.IsNullOrEmpty(IFheight.text))
        {
            guide = "������ �Է��� �ּ���.";
            guideTxt.text = guide;
        }

        else if (string.IsNullOrEmpty(IFweight.text))
        {
            guide = "ü���� �Է��� �ּ���.";
            guideTxt.text = guide;
        }

        else if (string.IsNullOrEmpty(IFdoctor.text))
        {
            guide = "����Ǹ� �Է��� �ּ���.";
            guideTxt.text = guide;
        }

        else if (string.IsNullOrEmpty(IFetc.text))
        {
            guide = "��Ÿ�� �Է��� �ּ���.";
            guideTxt.text = guide;
        }


        else
        {
            if (!string.IsNullOrEmpty(IFgender.text))
            {
                if (IFgender.text != "��" && IFgender.text != "��")
                {
                    guide = "������ Ȯ���� �ּ���.";
                    guideTxt.text = guide;
                }

                if (IFgender.text == "��" || IFgender.text == "��")
                {
                    infoData.profile = true;
                    Function_InputField();
                }
            }
        }
    }

}
