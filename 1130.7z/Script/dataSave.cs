using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


[System.Serializable] // ����ȭ �ؾ� �� �ٷ� �����͵��� �����Ǿ� ���� ��ġ�� �а� ���Ⱑ ��������.
public class SaveData_Game
{
    public bool isScene;
    public bool isWalking;
    public bool isReset_w;

    public bool isReset_m;

    public List<int> level_walk = new List<int>();
    public List<int> level_model = new List<int>();
    public List<string> petName = new List<string>();
    public List<string> characterName_walk = new List<string>();
    public List<string> characterName_model = new List<string>();
    public List<string> ingameName = new List<string>();
    public List<string> popupName = new List<string>();
}

[System.Serializable]
public class SaveData_Info
{
    public bool isCheck;
    public bool login;
    public bool profile;

    //public List<string, string> a = new List<string, string>();

    public List<string> id = new List<string>();
    public List<string> pass = new List<string>();

    public List<string> gender = new List<string>();
    public List<string> age = new List<string>();
    public List<string> height = new List<string>();
    public List<string> weight = new List<string>();
    public List<string> doctor = new List<string>();
    public List<string> etc = new List<string>();
}

public class dataSave : MonoBehaviour
{
    //private SaveData_Game gameData = new SaveData_Game();
    //private SaveData_Info infoData = new SaveData_Info();

    /*
    private void Start()
    {
        string json = JsonUtility.ToJson(infoData);
        File.WriteAllText(Application.dataPath + "/Resources/infoData.json", json);

        string gameJs = JsonUtility.ToJson(gameData);
        File.WriteAllText(Application.dataPath + "/Resources/gameData.json", gameJs);
    }
    */ 
}
