using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Rehabilitation : MonoBehaviour
{
    public GameObject character, Recamera, trampoline;
    public Animator animator;
    
    [SerializeField] private int num,num2;

    public float time;
    public Text CountTime;
    string Count;

    // �ڷΰ���
    public void back()
    {
        character.SetActive(false);
        Recamera.SetActive(false);
        trampoline.SetActive(false);
    }

    // �������� -> �����
    public void sels(int i)
    {
        switch (i)
        {
            //10��
            case 0:
                time = 3600;
                break;

            //20��
            case 1:
                time = 7200;
                break;


            //30��
            case 2:
                time = 10800;
                break;

        }
    }

    public void open() // ����
    {
        CountTime.text = "0 : 0";
        character.SetActive(true);
        Recamera.SetActive(true);
        trampoline.SetActive(true);

        sels(0);

        healthCount = 0;
        animator.Play("1_standing");
        num = animator.GetInteger("Re_Num"); 
        isSub = animator.GetBool("R_sub");
    }

    int healthCount; //�ｺī��Ʈ
    public bool istrue; //�ð�

    public float time2;
    bool isSub, check;

    private void count()
    {
        if (animator.IsInTransition(0))
        {
            if(num != num2)
            {
                num2 = num;
            }
        }

        if (!animator.IsInTransition(0))
        {
            istrue = true;
            if (num == num2)
            {
                check = true;
            }
        }

        if (time2 >= 10)
        {
            time2 = 0;
            num2 = num;

            num++;
            animator.SetInteger("Re_Num", num);
            check = false;
        }

        if (check)
        {
            time2 += Time.deltaTime;
        }


        animator.SetBool("R_sub", isSub);

    }


    void Update()
    {
        count();

        if (num >= 12)
        {
            healthCount += 1;
            Debug.Log("���� ���: " + healthCount);
            Debug.Log("���� ����: " + num);

            animator.Play("1_standing");
            num = 0;
            animator.SetInteger("Re_Num", 0);
            istrue = false;
        }

        //�ð� ī��Ʈ
        if (istrue)
        {
            time -= Time.deltaTime;
            Count = ((int)time / 360 % 60).ToString();
            CountTime.text = Count + " : " + ((int)time % 60).ToString();
        }
    }
}
