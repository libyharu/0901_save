using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using System.IO;
using UnityEngine.SceneManagement;

public class Popup : MonoBehaviour
{
    /// <summary>
    /// ���� �𵨰� ��ũ�� ������� �̿��Ҽ� �ֵ���
    /// </summary>
    
    public GameObject ModelCamera;

    // walk â
    public GameObject popWalk;

    //â
    public GameObject model, popModel, difficult, character, selGame;

    //ĳ����
    public GameObject trampoline, player,reha;

    public bool CheckModel, CheckWalk;

    //save
    private SaveData_Game gameData = new SaveData_Game();
    private string loadgame;
    bool a;

    private void Start()
    {
        Time.timeScale = 0;
    }

    void load()
    {
        loadgame = File.ReadAllText(Application.dataPath + "/Resources/gameData.json");
        gameData = JsonUtility.FromJson<SaveData_Game>(loadgame);


        for (int j = 0;j < gameData.characterName_walk.Count; j++){

            if (gameData.characterName_walk.Count != 1)
            {
                j = gameData.characterName_walk.Count - 1;
                if (gameData.characterName_walk[j] == "Reha_female_instructor")
                {
                    player = reha;
                }
            }
        }
    }


    public void StopGoing2(int i)  //<�˾� �� ��ư>
    {
        load();

        switch (i)
        {
            case 0: // �ʱ�ȭ
                Time.timeScale = 1;
                for (int j = 0; j < gameData.ingameName.Count; j++)
                {

                    if (gameData.ingameName.Count != 1)
                    {
                        j = gameData.ingameName.Count - 1;
                    }

                    if (gameData.ingameName[j] == "In Game Model") {

                        popModel.SetActive(false);
                        model.SetActive(false);
                        character.SetActive(false);
                        difficult.SetActive(false);
                        trampoline.SetActive(false);
                    }

                    if (gameData.ingameName[j] == "In Game Walk")
                    {
                        gameData.isScene = false;
                        SceneManager.LoadScene("RnD");
                    }
                   
                }
                break;

            case 1: //walk - ȭ�鿡�� �����
                Time.timeScale = 1;
                popWalk.SetActive(false);

                if (gameData.isReset_w) // �� ���� �� �����
                {
                    //gameData.isReset_w = false;
                    //SceneManager.LoadScene("Test");
                    SceneManager.LoadScene("walk");
                }
                if (!gameData.isReset_w) //�Ͻ����� �����
                {
                    //gameData.isReset_w = false;
                }
                break;


            case 2: //model - ȭ�鿡�� �����, �Ͻ������� ��ǥ�� ���� walk�� ����
                Time.timeScale = 1;
                popModel.SetActive(false);

                if (gameData.isReset_m) //��ǥ���� �� �����
                {
                    // ���� �� Ŭ�� �κ�
                    character.SetActive(false);
                    trampoline.SetActive(false);
                }

                if (!gameData.isReset_m)  // �Ͻ����� �����
                {
                    ModelCamera.SetActive(true);
                }
                break;
        }

        save();
    }

    void save()
    {
        string gameJs = JsonUtility.ToJson(gameData);
        File.WriteAllText(Application.dataPath + "/Resources/gameData.json", gameJs);

    }

}
