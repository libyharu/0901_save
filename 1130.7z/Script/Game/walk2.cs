using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class walk2 : MonoBehaviour
{
    //üũ
    public bool WalkingTimer, CheckWalk;

    #region �����̵�, Ÿ�̸�
    public Slider slider;
    public float time;
    public Text clockT;
    string clockText;
    #endregion

    #region ĳ����, ī�޶�, ����, ��, �˾� ��
    public GameObject WalkCamera, walkGame;

    public GameObject plane1, inplane;
    public GameObject goal;

    public GameObject Character;
    string characterName_walk;
    public GameObject woman, man;
    public GameObject popup;
    #endregion

    //Ʈ���޸� ���̵� ui
    public Image[] img;

    private int j, level_walk;

    private SaveData_Game gameData = new SaveData_Game();
    private string loadgame;

    public Text txt;
    private Vector3 pos, pos2;
    public GameObject obs, folder;
    private float timer;

    bool a = true;

    public GameObject cube1, cube2;

    void test2()
    {

        float randomZ = Random.Range(cube1.transform.position.z, cube2.transform.position.z);
        float randomX = Character.transform.position.x - 3f;

        timer -= Time.deltaTime;

        if (timer <= 0.0f)
        {
            GameObject obj = (GameObject)Instantiate(obs, new Vector3(randomX, Character.transform.position.y, randomZ), Quaternion.identity);

            obj.transform.parent = folder.transform;
            timer = 20f;
        }

    }


    //map
    void test()
    {
        // ��) ĳ������ x���� �������� ����
        float randomX = Random.Range(Character.transform.position.x -10f, Character.transform.position.x + 10f);
        float randomZ = Character.transform.position.z - 10f;

        timer -= Time.deltaTime;

        if (timer <= 0.0f)
        {
            GameObject obj = (GameObject)Instantiate(obs, new Vector3(randomX, Character.transform.position.y, randomZ), Quaternion.identity);

            obj.transform.parent = folder.transform;
            timer = 20f;
        }

    }


    public void Start()
    {
        daum();
        Animator a = Character.GetComponent<Animator>();
        pos = Character.transform.position;
    }

    public void ingame_Pause()
    {
        popup.SetActive(true);
        Time.timeScale = 0;
        pos2 = Character.transform.position;

        gameData.isReset_w = false;
        save();
    }

    public void Load()
    {
        loadgame = File.ReadAllText(Application.dataPath + "/Resources/gameData.json");
        gameData = JsonUtility.FromJson<SaveData_Game>(loadgame);

        CheckWalk = gameData.isWalking;

        for (int i = 0; i < gameData.level_walk.Count; i++)
        {
            if(gameData.level_walk.Count != 1)
            {
                i = gameData.level_walk.Count-1;

                level_walk = gameData.level_walk[i];
            }
            else
            {
                level_walk = gameData.level_walk[i];
            }
        }
        for (int i = 0; i < gameData.characterName_walk.Count; i++)
        {
            if (gameData.characterName_walk.Count != 1)
            {
                i = gameData.characterName_walk.Count -1;

                characterName_walk = gameData.characterName_walk[i];
            }

            else
            {
                characterName_walk = gameData.characterName_walk[i];
            }
        }
    }

    void save()
    {
        string gameJs = JsonUtility.ToJson(gameData);
        File.WriteAllText(Application.dataPath + "/Resources/gameData.json", gameJs);

    }

    public void daum()
    {
        Load();

        if (characterName_walk == "woman")
        {
            Character = woman;
        }
        else if (characterName_walk == "man")
        {
            Character = man;
        }
        gameData.isReset_w = false;
        level_walkCheck(level_walk);
        time = 0;
    }

    void level_walkCheck(int level_walk)
    {
        if (level_walk <= 0)
        {
            level_walk = 1;
        }
        switch (level_walk)
        {
            case 1:
                inplane = plane1;
                break;

            case 2:
                inplane = plane1;
                break;

            case 3:
                inplane = plane1;
                break;
        }

        slider.maxValue = Vector3.Distance(Character.transform.position, goal.transform.position);
        slider.value = 0;

        Character.SetActive(true);
    }

    //OnGui
    public void OnGUI()
    {
        Event e = Event.current;

        if (!Input.anyKey)
        {
            j = 4;
            colorchange(0);
        }

        #region Ű�� ���� 
        if (Input.anyKeyDown)
        {
            if (e.isKey)
            {
                st = true;

                if (e.keyCode == KeyCode.UpArrow)
                {
                    j = 0;
                    colorchange(0);
                }

                else if (e.keyCode == KeyCode.LeftArrow)
                {
                    j = 1;
                    colorchange(0);
                }
                else if (e.keyCode == KeyCode.RightArrow)
                {
                    j = 2;
                    colorchange(0);
                }
                else if (e.keyCode == KeyCode.DownArrow)
                {
                    j = 3;
                    colorchange(0);
                }
            }
        }
        #endregion


        #region Ű�� ������ ��
        if (e.type == EventType.KeyUp)
        {
            if (e.isKey)
            {
                if (e.keyCode == KeyCode.UpArrow)
                {
                    j = 0;
                    colorchange(1);
                }
                else if (e.keyCode == KeyCode.LeftArrow)
                {
                    j = 1;
                    colorchange(1);
                }
                else if (e.keyCode == KeyCode.RightArrow)
                {
                    j = 2;
                    colorchange(1);
                }
                else if (e.keyCode == KeyCode.DownArrow)
                {
                    j = 3;
                    colorchange(1);
                }
            }
        }
        #endregion
    }

    //���� �ٲٴ� ��
    void colorchange(int i)
    {
        Color color;
        switch (i)
        {
            case 0:
                color = img[j].color;
                color = new Color(1, 1, 0);
                color.a = 1f;
                img[j].color = color;
                break;

            case 1:
                color = img[j].color;
                color = new Color(1, 1, 1);
                color.a = 0.4f;
                img[j].color = color;
                break;
        }
    }

    void posCheck()
    {      
        float dis = Vector3.Distance(Character.transform.position, goal.transform.position);

        if(dis < 4.5f)
        {
            Load();
        }

        if (gameData.isReset_w)
        {
            pos2 = Character.transform.position;
            float posMinus = Vector3.Distance(pos, pos2);
            txt.text = "�̵��Ÿ�: " + posMinus.ToString();

            popup.SetActive(true);
        }
    }

    bool st;
    private void Update()
    {
        if (st)
        {
            test();
        }

        //Ÿ�̸�
        time += Time.deltaTime;
        clockText = ((int)time / 60 % 60).ToString();
        clockT.text = clockText + " : " + ((int)time % 60).ToString();

        if (Character != null)
        {
            //���� ���� �����
            float dis = Vector3.Distance(Character.transform.position, goal.transform.position);
            slider.value = slider.maxValue - dis;
        }

        posCheck();
    }
}
