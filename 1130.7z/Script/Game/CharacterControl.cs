using UnityEngine;
using System.IO;


public class CharacterControl : MonoBehaviour
{
    public Animator character;
    public GameObject woman, man;
    public GameObject popup, walkGame;
    public GameObject player;
    public GameObject goal;

    //�ȱ�
    //public Vector3 pos, moveDistance, rotaDistance;
    //public Quaternion rota;

    private float check; //Ŭ���� Ŭ������ ����.
    private bool click;
    private float DobleClickSecond = 0.25f; //����Ŭ���� ������ �ð�

    [SerializeField] private float time;
    [SerializeField] private bool click2;

    private bool isWalking;
    private int level_walk;

    public Transform st1;

    //save
    private SaveData_Game gameData = new SaveData_Game();
    private string loadgame;
    string characterName_walk;

    public void Load()
    {
        loadgame = File.ReadAllText(Application.dataPath + "/Resources/gameData.json");
        gameData = JsonUtility.FromJson<SaveData_Game>(loadgame);

        for (int i = 0; i < gameData.level_walk.Count; i++)
        {
            if (gameData.level_walk.Count != 1)
            {
                i = gameData.level_walk.Count - 1;

                level_walk = gameData.level_walk[i];
            }
            else
            {
                level_walk = gameData.level_walk[i];
            }
        }

        for (int i = 0; i < gameData.characterName_walk.Count; i++)
        {
            if (gameData.characterName_walk.Count != 1)
            {
                i = gameData.characterName_walk.Count - 1;

                characterName_walk = gameData.characterName_walk[i];
            }
            else
            {
                characterName_walk = gameData.characterName_walk[i];
            }
        }
    }

    public void Start()
    {
        Load();

        // popup - goal
        gameData.isWalking = false;

        //player = woman;
        if (characterName_walk == "woman")
        {
            player = woman;
        }
        if (characterName_walk == "man")
        {
            player = man;
        }

        level_walkCheck(level_walk);
    }


    //��å������ �Ÿ��� ����
    //��ǥ���� �޶��� ��
    void level_walkCheck(int level_walk)
    {
        #region level_walk
        //switch (level_walk)
        //{
        //    case 1:
        //        //_startTarget = st1;
        //        break;

        //    case 2:
        //        //_startTarget = st1;
        //        break;

        //    case 3:
        //        //_startTarget = st1;
        //        break;
        //}
        //player.transform.position = _startTarget.transform.position;
        //player.SetActive(true);
        #endregion
        character = player.GetComponent<Animator>();
    }

    public bool refRigh;

    private void OnGUI()
    {
        Event e = Event.current;
        if (Input.anyKeyDown)
        {
            if (e.isKey)
            {
                #region ĳ���� �ִϸ�����

                if (e.keyCode == KeyCode.UpArrow)
                {
                    character.Play("WalkFwdLoop");
                    if (!click)
                    {
                        click = true;
                        check = 0f;

                        character.speed = 1;
                        refRigh = false;
                    }
                    else if (click == true && check != 0 && check <= DobleClickSecond) //Ŭ�������� true�̰� timer ������ <= DobleClickSecond �̸�
                    {
                        click = false;
                        check = 0f;

                        character.speed = 1.5f;
                        refRigh = true;
                    }
                    else
                    {
                        check = 0f;
                        character.speed = 1;
                        refRigh = false;
                    }
                }

                if (e.keyCode == KeyCode.LeftArrow)
                {
                    character.Play("StrafeLeft45Loop");
                }

                if (e.keyCode == KeyCode.RightArrow)
                {
                    //click2 = true;
                    character.Play("right");
                    #region click2
                    if (click2)
                    {
                        character.Play("right");
                    }
                    if (refRigh)
                    {
                        character.speed = 1.5f;
                    }
                    else if (!refRigh)
                    {
                        character.speed = 1f;
                    }
                    #endregion
                }
                #endregion

                if (e.keyCode == KeyCode.A)
                {
                    character.Play("Idle");
                }
            }
        }

        #region keyup
        if (e.type == EventType.KeyUp)
        {
            isWalking = character.GetBool("isWalk");

            isWalking = true;
            character.SetBool("isWalk", isWalking);

            if (e.keyCode == KeyCode.LeftArrow)
            {
                click2 = false;
                time = 0f;
            }
            if (e.keyCode == KeyCode.RightArrow)
            {
                click2 = false;
                time = 0f;
            }

        }
        #endregion
    }


    void clickManager()
    {
        if (click)
        {
            check += Time.deltaTime;
        }

        if (click2)
        {
            time += Time.deltaTime;
        }

        if (time > 0.75f)
        {
            click2 = false;
            time = 0f;

            isWalking = character.GetBool("isWalk");

            isWalking = true;
            character.SetBool("isWalk", isWalking);
        }

    }

    private void rayCheck()
    {
        RaycastHit hit;

        if (Physics.Raycast(character.transform.position, character.transform.forward , out hit, 3f))
        {
            if (hit.collider.tag == "Goal")
            {
                gameData.isReset_w = true;
                save();
            }
        }
    }

    private void save()
    {
        string gameJs = JsonUtility.ToJson(gameData);
        File.WriteAllText(Application.dataPath + "/Resources/gameData.json", gameJs);
    }

    private void Update()
    {
        //����Ŭ��
        clickManager();
        rayCheck();
    }



}

