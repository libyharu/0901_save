using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TEst2 : MonoBehaviour
{
    public Animator character;
    public GameObject popup, walkGame;

    public GameObject player;
    public GameObject goal;


    private float check; //Ŭ���� Ŭ������ ����.
    private bool click;
    private float DobleClickSecond = 0.25f; //����Ŭ���� ������ �ð�


    [SerializeField] private float time;
    [SerializeField] private bool click2;

    private Vector3 destination;

    private bool isWalking;
    int Level;

    public Transform st1;
    Transform _startTarget;

    public void gameCheck()
    {
        //player = GameObject.Find("Character Selection").GetComponent<SelectCharacter>().character;
        //Level = GameObject.Find("SceneManager").GetComponent<SceneManager>().level;

        if (walkGame.activeSelf)
        {
            levelCheck(Level);

        }
    }
    void levelCheck(int level)
    {
        switch (level)
        {
            case 1:
                _startTarget = st1;
                break;

            case 2:
                _startTarget = st1;
                break;

            case 3:
                _startTarget = st1;
                break;
        }
        player.transform.position = _startTarget.transform.position;
        player.SetActive(true);

        //GameObject.Find("GameManager").GetComponent<CharacterControl>().enabled = true;
        //character = player.GetComponent<Animator>();
        //character.applyRootMotion = true;
    }

    private void OnGUI()
    {
        Event e = Event.current;
        if (Input.anyKeyDown)
        {
            if (e.isKey)
            {
                isWalking = character.GetBool("isWalk");

                isWalking = false;
                character.SetBool("isWalk", isWalking);

                if (e.keyCode == KeyCode.UpArrow)
                {
                    character.Play("WalkFwdLoop");
                    if (!click)
                    {
                        click = true;
                        check = 0f;

                        character.speed = 1;
                    }
                    else if (click == true && check != 0 && check <= DobleClickSecond) //Ŭ�������� true�̰� timer ������ <= DobleClickSecond �̸�
                    {
                        click = false;
                        check = 0f;

                        character.speed = 1.5f;
                    }
                    else
                    {
                        check = 0f;
                        character.speed = 1;
                    }
                }

                if (e.keyCode == KeyCode.LeftArrow)
                {
                    click2 = true;

                    if (click2)
                    {
                        character.Play("StrafeLeft45Loop");
                    }
                }

                if (e.keyCode == KeyCode.RightArrow)
                {
                    click2 = true;

                    if (click2)
                    {
                        character.Play("right");
                    }
                }

            }
        }

        if (e.type == EventType.KeyUp)
        {
            isWalking = character.GetBool("isWalk");

            isWalking = true;
            character.SetBool("isWalk", isWalking);

            if (e.keyCode == KeyCode.LeftArrow)
            {
                click2 = false;
                time = 0f;

                character.speed = 1f;
            }
            if (e.keyCode == KeyCode.RightArrow)
            {
                click2 = false;
                time = 0f;

                character.speed = 1f;
            }

        }
    }

    void posCheck()
    {
        destination = goal.transform.position;

        float dis = Vector3.Distance(player.transform.position, destination);

        if (dis <= 3f)
        {
            character.Play("Idle");
            popup.SetActive(true);
        }
    }

    private void Update()
    {
        if (walkGame.activeSelf)
        {
            posCheck();

            //����Ŭ��
            if (click)
            {
                check += Time.deltaTime;
            }

            if (click2)
            {
                time += Time.deltaTime;

                character.speed = 2f;
            }

            if (time > 0.75f)
            {
                click2 = false;
                time = 0f;

                isWalking = character.GetBool("isWalk");

                isWalking = true;
                character.SetBool("isWalk", isWalking);

                character.speed = 1f;
            }

            if (popup.activeSelf)
            {
                player.SetActive(false);
                character.applyRootMotion = false;
            }


        }

    }
}
