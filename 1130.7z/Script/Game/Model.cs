using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class Model : MonoBehaviour
{
    public GameObject cam;
    public GameObject ModelCamera, ingame, popup, trampoline, pos;
    public GameObject Guide, GuideTimer;
    public GameObject Player;

    public Text GuitdTimerT, clockT2;
    private string clockText2;

    private bool up, down, right, left, middle;
    public Image[] img;

    public Slider slider;
    private float time, sliderTime;
    private int j;

    public Text txt, txt2, txt3, txt4;
    private string hint, result;

    private float max_Time;
    private int level_model;
    private float tm;

    [SerializeField] private int s = 0; //ó�� �����Ҷ��� ����
    [SerializeField] private bool isMove;
    [SerializeField] private bool sub;
    private bool atouch;
    private float touchTime;
    private int num;
    private int num2 = 0;
    private int count, count2; // ����Ƚ��, ����Ƚ��

    public Animator character;
    private bool isResult;
    public bool popCheck;

    private void Update()
    {
        if (ingame.activeSelf)
        {
            //3,2,1
            if (Guide.activeSelf == true)
            {
                ttf();
            }

            //Ÿ�̸�
            sliderTimer();

            if (Player.activeSelf == true)
            {
                //�ִϸ�����
                timer();

                //3�� Ȯ��
                if (atouch)
                {
                    touchTime += Time.deltaTime;
                }

                numChange();

                //popup
                if (num >= 12)
                {
                    popupManager();
                    gameData.isReset_m = true;
                }
            }

            //Ű üũ
            KeyCheck();
            popupManager();
        }

    }

    //�Ͻ����� ��ư
    public void ingame_Pause()
    {
        gameData.isReset_m = false;

        ModelCamera.SetActive(false);
        pos.SetActive(false);
        popup.SetActive(true);
        Time.timeScale = 0;

        txt.text = "���� ����: " + count.ToString() + " ��";
        txt2.text = "���� ����: " + count2.ToString() + " ��";

        save();
    }

    //�ʱ�ȭ
    public void popupManager()
    {
        if (gameData.isReset_m) // �ʱ�ȭ
        {
            ModelCamera.SetActive(false);
            pos.SetActive(false);
            popup.SetActive(true);

            txt.text = "���� ����: " + count.ToString() + " ��";
            txt2.text = "���� ����: " + count2.ToString() + " ��";
            txt3.text = null; // �ȳ�����
            txt4.text = null; // ���ǥ��

            isMove = false;
            num = -1;
            num2 = 0;

            character.SetInteger("Model_Num", num);
            character.SetBool("isMove", isMove);

            slider.value = 0;


            isResult = false;
            //-------------------------------------------
        }
        save();
    }

    //Gui
    public void OnGUI()
    {
        Event e = Event.current;

        //Ű�� ����
        if (Input.anyKeyDown)
        {
            //Debug.Log(gameData.isReset);
            //Debug.Log(gameData.isGoing);

            if (e.isKey)
            {
                if (isMove)
                {
                    atouch = true;
                }

                if (e.keyCode == KeyCode.UpArrow)
                {
                    j = 0;
                    up = true;
                }
                else if (e.keyCode == KeyCode.LeftArrow)
                {
                    j = 1;
                    left = true;
                }
                else if (e.keyCode == KeyCode.RightArrow)
                {
                    j = 2;
                    right = true;
                }
                else if (e.keyCode == KeyCode.DownArrow)
                {
                    j = 3;
                    down = true;
                }
                else if (e.keyCode == KeyCode.Z)
                {
                    j = 4;
                    middle = true;
                }

            }
        }

        //Ű�� ������ ��
        if (e.type == EventType.KeyUp)
        {
            if (e.isKey)
            {
                if (isMove)
                {
                    atouch = false;
                }

                if (e.keyCode == KeyCode.UpArrow)
                {
                    up = false;
                    j = 0;
                }
                else if (e.keyCode == KeyCode.LeftArrow)
                {
                    left = false;
                    j = 1;
                }
                else if (e.keyCode == KeyCode.RightArrow)
                {
                    right = false;
                    j = 2;
                }
                else if (e.keyCode == KeyCode.DownArrow)
                {
                    down = false;
                    j = 3;
                }
                else if (e.keyCode == KeyCode.Z)
                {
                    middle = false;
                    j = 4;
                }

            }
        }
    }

    private SaveData_Game gameData = new SaveData_Game();

    private string loadgame;

    private void Load()
    {
        loadgame = File.ReadAllText(Application.dataPath + "/Resources/gameData.json");
        gameData = JsonUtility.FromJson<SaveData_Game>(loadgame);


        for (int i = 0; i < gameData.level_model.Count; i++)
        {
            if (gameData.level_model.Count != 1)
            {
                i = gameData.level_model.Count-1;

                level_model = gameData.level_model[i];
            }
            else
            {
                level_model = gameData.level_model[i];
            }
        }
    }

    private void save()
    {
        string gameJs = JsonUtility.ToJson(gameData);
        File.WriteAllText(Application.dataPath + "/Resources/gameData.json", gameJs);
    }

    //�ʱ�ȭ
    public void ModelCheck()
    {
        if (!gameData.isReset_w && ingame.activeSelf)
        {
            //�Ͻ����������� ��ġ�� �ȵ�

            Load();
            gameData.isReset_m = false;

            //����
            cam.SetActive(false);
            trampoline.SetActive(true);
            pos.SetActive(true);

            //�ʱ�ȭ
            level_modelcheck(level_model);

            clockT2.text = "0 : 0";

            Guide.SetActive(true);
            GuideTimer.SetActive(true);

            time = 2;

            count = 0;
            count2 = 0;

            hint = "�ȳ� ����";
            txt3.text = hint;

            result = "��� ǥ��";
            txt4.text = result;

            isMove = character.GetBool("isMove");
            num = character.GetInteger("Model_Num");
            sub = character.GetBool("sub");
        }

        gameData.isReset_w = false;
    }

    void level_modelcheck(int level_model)
    {
        switch (level_model)
        {
            case 1:
                max_Time = 11f;
                //tm = 3;
                tm = 2;
                break;

            case 2:
                max_Time = 13f;
                //tm = 5;
                tm = 2;
                break;

            case 3:
                max_Time = 16f;
                //tm = 7;
                tm = 2;
                break;
        }

        slider.maxValue = max_Time;
        sliderTime = max_Time;
    }


    //update - guide
    void ttf()
    {
        if (0 < time)
        {
            time -= Time.deltaTime;
            GuitdTimerT.text = string.Format("{0:N0}", time);
        }

        else
        {
            GuideTimer.SetActive(false);

            ModelCamera.SetActive(true);
            Guide.SetActive(false);
            Player.SetActive(true);
            character.enabled = true;
            character.Play("model");

            slider.value = slider.maxValue;
        }
    }

    //update �ٷ�
    void sliderTimer()
    {

        if (isMove && !character.IsInTransition(0))
        {
            if (character.IsInTransition(0))
            {
                returns();
            }

            slider.value -= Time.deltaTime;
            sliderTime -= Time.deltaTime;

            clockText2 = ((int)sliderTime / 60 % 60).ToString();
            clockT2.text = clockText2 + " : " + ((int)sliderTime % 60).ToString();

            if (slider.value <= 0 || sliderTime <= 0)
            {
                if (!isResult && !atouch)
                {
                    notsucess(1);
                }

                returns();

            }
        }
    }

    void timer()
    {
        // get �ڸ����� �� 

        if (character.IsInTransition(0) && num >= 1)
        {
            isMove = false;
            character.SetBool("isMove", isMove);

            hint = "���� �ִϸ��̼� ��";
            txt3.text = hint;

        }

        if (!character.IsInTransition(0))
        {
            //ù ���� - num = 0
            if (character.GetCurrentAnimatorStateInfo(0).IsName("1_0"))
            {
                hint = "���� �ִϸ��̼� ��";
                txt3.text = hint;
            }

            else if (character.GetCurrentAnimatorStateInfo(0).IsName("1_1") && num < 0)
            {
                hint = "���� �ִϸ��̼� ��";
                txt3.text = hint;
                num = 0;
                character.SetInteger("Model_Num", num);

            }
            else if (num == num2)
            {
                hint = "������ ���� �ϴ� �κ�";
                txt3.text = hint;
                isMove = true;
                character.SetBool("isMove", isMove);

                s = 1;
            }

            //slider & animator
            else if (num != num2 && isMove == false)
            {

                if (character.GetCurrentAnimatorStateInfo(0).IsName("model"))
                {
                    hint = "�ȳ� ����";
                    txt3.text = hint;
                }
                else if (num >= 1)
                {
                    isMove = true;
                    character.SetBool("isMove", isMove);

                    if (num == 4 && s == 1)
                    {
                        sub = true;
                        character.SetBool("sub", sub);

                        if (character.GetCurrentAnimatorStateInfo(0).IsName("5_0"))
                        {
                            sub = false;
                            character.SetBool("sub", sub);
                            s = 2;
                            hint = "���� �ִϸ��̼� ��";
                            txt3.text = hint;
                        }
                    }

                    if (num == 6 && s == 2)
                    {
                        sub = true;
                        character.SetBool("sub", sub);

                        if (character.GetCurrentAnimatorStateInfo(0).IsName("7_0"))
                        {
                            sub = false;
                            character.SetBool("sub", sub);
                            s = 3;
                            hint = "���� �ִϸ��̼� ��";
                            txt3.text = hint;
                        }
                    }

                    else
                    {
                        hint = "������ ���� �ϴ� �κ�";
                        txt3.text = hint;

                    }

                }

            }

        }
  
    }

    void KeyCheck()
    {
        if (j == 0)
        {
            if (up) { colorchange(0); }
            if (!up) { colorchange(1); }
        }
        if (j == 1)
        {
            if (left) { colorchange(0); }
            if (!left) { colorchange(1); }
        }
        if (j == 2)
        {
            if (right) { colorchange(0); }
            if (!right) { colorchange(1); }
        }
        if (j == 3)
        {
            if (down) { colorchange(0); }
            if (!down) { colorchange(1); }
        }

        if (j == 4)
        {
            if (middle) { colorchange(0); }
            if (!middle) { colorchange(1); }
        }
    }

    //���� �ٲٴ� ��
    void colorchange(int i)
    {
        Color color;
        switch (i)
        {
            case 0:
                color = img[j].color;
                color = new Color(1, 1, 0);
                color.a = 1f;
                img[j].color = color;
                break;

            case 1:
                color = img[j].color;
                color = new Color(1, 1, 1);
                color.a = 0.4f;
                img[j].color = color;
                break;
        }
    }

    //atouch - ����
    void numChange()
    {
        if (atouch)
        {
            if (touchTime >= tm)
            {
                sucess();
            }
        }

        if (!atouch && touchTime !=0)
        {
            if (touchTime < tm)
            {
                notsucess(0);
            }
        }
    }

    //�����̴�
    void returns()
    {
        isResult = false;
        atouch = false;
        isMove = false;
        character.SetBool("isMove", isMove);
        sliderTime = max_Time;
        slider.value = slider.maxValue;
    }

    //����
    void notsucess(int i)
    {
        isMove = false;
        character.SetBool("isMove", isMove);

        switch (i) {
            case 0:
                touchTime = 0;

                result = "����, �ð��� �ɶ����� �õ�";
                txt4.text = result;
                break;

            case 1:
                atouch = false;
                touchTime = 0;
                count2 += 1;

                result = "����, �ð� ��";
                txt4.text = result;

                if (num == 0 && num2 == 0)
                {
                    num = 1;
                    character.SetInteger("Model_Num", num);
                }

                else if (num2 != num)
                {
                    num2 = num;
                    num++;
                    character.SetInteger("Model_Num", num);
                }
                break;
        }
    }

    //����
    void sucess()
    {
        isMove = false;
        character.SetBool("isMove", isMove);
        atouch = false;
        touchTime = 0;
        count++;

        result = "����";
        txt4.text = result;

        returns();

        isResult = true;

        if (num == 0 && num2 == 0)
        {
            num = 1;
            character.SetInteger("Model_Num", num);
        }

        else if (num2 != num)
        {
            num2 = num;
            num++;
            character.SetInteger("Model_Num", num);
        }
    }

}
