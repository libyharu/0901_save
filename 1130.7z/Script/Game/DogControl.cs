using UnityEngine;
using UnityEngine.AI;
using System.IO;

public class DogControl : MonoBehaviour
{
    //�����Ӱ� ���ƴٴϸ鼭 ��ǥ�� ���� ���� �� -> ��ǥ�� ���鼭 ��ֹ����� �����Ͽ� �����̴� ��

    #region ���� ����
    public enum State
    {
        idle, walk, run, follow, wait,late
        //- ������ Ǯ�� - �����ñ� �߰�
    };
    public State state;
    #endregion

    public bool isMove;
    private int level_walk;

    //get �Լ�
    public Rigidbody dogRigidbody;
    public Animator ani;
    public NavMeshAgent agent;

    #region �� ������ â
    public GameObject dog, character, WalkGame, popup;
    #endregion

    #region �ش� ��ũ��Ʈ �κ�
    private float walkSpeed, runSpeed, max_speed;  // �ȱ� �ٱ� -> �ٴ� �ӵ��� ����������� �ʿ�
    public GameObject Guide;
    public RaycastHit hit;
    public Transform target;
    private bool walk, run;
    private bool downcheck;
    private float dis, time3;
    private Vector3 velocity = Vector3.zero;
    float g;
    #endregion

    #region save ���
    private SaveData_Game saveData = new SaveData_Game();
    private string gameData;
    private string petName;
    private string characterName_walk;
    public GameObject woman, man;
    public GameObject animal1, animal2;
    #endregion

    public void Load()
    {
        #region
        gameData = File.ReadAllText(Application.dataPath + "/Resources/gameData.json");
        saveData = JsonUtility.FromJson<SaveData_Game>(gameData);
        for (int i = 0; i < saveData.level_walk.Count; i++)
        {
            if (saveData.level_walk.Count != 1)
            {
                i = saveData.level_walk.Count-1;

                level_walk = saveData.level_walk[i];
            }
            else
            {
                level_walk = saveData.level_walk[i];
            }
        }

        for (int i = 0; i < saveData.characterName_walk.Count; i++)
        {
            if (saveData.characterName_walk.Count != 1)
            {
                i = saveData.characterName_walk.Count-1;

                characterName_walk = saveData.characterName_walk[i];
            }

            else
            {
                characterName_walk = saveData.characterName_walk[i];
            }
        }
        for (int i = 0; i < saveData.petName.Count; i++)
        {
            if (saveData.petName.Count != 1)
            {
                i = saveData.petName.Count-1;

                petName = saveData.petName[i];
            }

            else
            {
                petName = saveData.petName[i];
            }
        }
        #endregion
    }

    public void Start()
    {
        Load();

        if (dog == null || character == null)
        {
            dog = animal1;
            character = woman;

            if (petName == "Dalmatian")
            {
                dog = animal1;
            }
        }

        if (characterName_walk == "woman")
        {
            character = woman;
        }
        if (characterName_walk == "man")
        {
            character = man;
        }

        agent = dog.GetComponent<NavMeshAgent>();

        dogRigidbody = dog.GetComponent<Rigidbody>();
        ani = dog.GetComponent<Animator>();
        Guide.SetActive(false);

        state = State.idle;

        Level(level_walk);
    }

    private void following()
    {
        Guide.SetActive(false);
        walkSpeed = runSpeed;

        dog.transform.position = Vector3.Lerp(dog.transform.position, character.transform.position, Time.deltaTime);
        walk = false;
        ani.SetBool("walk", walk);
        run = false;
        ani.SetBool("run", run);

        if (dis < 3.5f)
        {
            state = State.walk;
        }
    }

    private void Move()
    {
        agent.SetDestination(target.position);
    }

    private void Run()
    {
        dog.transform.position = Vector3.Lerp(dog.transform.position, hitTrans.position, Time.deltaTime * walkSpeed);
        dog.transform.LookAt(hitTrans);
    }

    private void Wait()
    {
        //float t1 = Time.deltaTime;
        //t1 += Time.deltaTime;

        ani.Play("Simple Idle");
        walk = false;
        ani.SetBool("walk", walk);
        run = false;
        ani.SetBool("run", run);

        //if (t1 > 5f)
        //{
        //    state = State.walk;
        //    t1 = 0f;
        //}
    }

    private void select()
    {
        //g += Time.deltaTime;

        //if(g >= 10f)
        //{
        //    float f = Random.Range(0, 10);
        //    if (f == 1)
        //    {
        //        state = State.wait;
        //    }

        //    g = 0;
        //}

        switch (state)
        {
            case State.idle:
                agent.isStopped = true;
                ani.Play("Simple Idle");
                walk = false;
                ani.SetBool("walk", walk);
                run = false;
                ani.SetBool("run", run);
                break;

            case State.walk:
                agent.isStopped = false;
                Move();
                break;

            case State.run:
                //reset�� ����
                Run();
                break;

            case State.follow:
                agent.isStopped = true;
                following();
                break;

            case State.wait:
                Wait();
                agent.isStopped = true;
                break;

        }

        #region ���� ����
        if (state == State.run || dis < 2f)
        {
            walk = false;
            ani.SetBool("walk", walk);
            run = true;
            ani.SetBool("run", run);

        }

        if (state == State.walk || dis >= 2f)
        {
            walk = true;
            ani.SetBool("walk", walk);
            run = false;
            ani.SetBool("run", run);
        }
        #endregion
    }

    float value, value2;
    bool args;

    private void arg()
    {
        // ĳ������ ��ó�� �;���

        Transform dogTrans = dog.transform;

        Transform characterTrans = character.transform;

        value = Mathf.Clamp(dogTrans.position.x,characterTrans.position.x-4f, characterTrans.position.x+4f );
        value2 = Mathf.Clamp(dogTrans.position.z, characterTrans.position.z-2f, characterTrans.position.z-4f); // ������ �޶������� ������ �ʿ��� ��

        Vector3 abs = new Vector3(value, dogTrans.position.y, value2);

        if(dogTrans.position.x < value)
        {
            dogTrans.position = Vector3.Lerp(dogTrans.position, abs, Time.deltaTime * walkSpeed);
            args = false;
        }
        else if (dogTrans.position.x > value)
        {
            dogTrans.position = Vector3.Lerp(dogTrans.position, abs, Time.deltaTime * walkSpeed);
            args = false;
        }

        //Z���� ĳ������ z������ �־����� �ȵǴµ�..

        else if (dogTrans.position.z < value2)
        {
            dogTrans.position = Vector3.Lerp(dogTrans.position, abs, Time.deltaTime * walkSpeed);
            args = false;
        }
        else if(dogTrans.position.z > value2)
        {
            dogTrans.position = Vector3.Lerp(dogTrans.position, abs, Time.deltaTime * walkSpeed);
            args = false;
        }

    }

    //level_walk �� runspeed, dog true
    private void Level(int level_walk)
    {
        switch (level_walk)
        {
            case 1:
                max_speed = 1.7f;
                break;

            case 2:
                max_speed = 1.7f;
                break;

            case 3:
                max_speed = 1.7f;
                break;
        }
        runSpeed = max_speed;
        walkSpeed = max_speed;

        dog.SetActive(true);
    }


    void FixedUpdate()
    {
        if (isMove)
        {
            select();
            FindVisibleTargets();
            dis = Vector3.Distance(character.transform.position, dog.transform.position);

            if (state == State.walk && dis > 5.5f)
            {
                args = true;
                if (args)
                {
                    arg();
                }
            }

            if (downcheck) // follow �� �缳�� �ð��� ���� �������� 0.5����
            {
                time3 += Time.deltaTime;

                if (time3 >= 5)
                {
                    downcheck = false;
                    time3 = 0f;
                }
            }

            if (click)
            {
                check += Time.deltaTime;
            }
        }
    }

    private float check; //Ŭ���� Ŭ������ ����.
    private bool click;
    private float DobleClickSecond = 0.25f; //����Ŭ���� ������ �ð�

    //follow 
    private void OnGUI()
    {
        Event e = Event.current;
        if (e.isKey)
        {
            if (Input.anyKeyDown)
            {
                if(e.keyCode == KeyCode.UpArrow)
                {
                    if (!click)
                    {
                        click = true;
                        check = 0f;
                        walkSpeed = max_speed;
                        agent.speed = walkSpeed;
                    }
                    else if (click == true && check != 0 && check <= DobleClickSecond)
                    {
                        click = false;
                        check = 0f;
                        walkSpeed = runSpeed;
                        agent.speed = walkSpeed;
                    }
                    else
                    {
                        check = 0f;
                        walkSpeed = max_speed;
                        agent.speed = walkSpeed;
                    }
                }

                if (e.keyCode == KeyCode.UpArrow || e.keyCode == KeyCode.RightArrow|| e.keyCode == KeyCode.LeftArrow)
                {
                    isMove = true;
                    agent.isStopped = false;
                    state = State.walk;
                }

                if (e.keyCode == KeyCode.DownArrow)
                {
                    if (Guide.activeSelf == true)
                    {
                        state = State.follow;
                        downcheck = true;
                    }
                }
            }
        }
    }


    //---------------------------------------------------------------------
    private float ViewAngle = 130;    //�þ߰�
    //private float ViewAngle2 = 90;    //�þ߰�
    private float ViewDistance = 20; //�þ߰Ÿ�

    public LayerMask ObstacleMask;  //Obstacle ���̾��ũ ���� ���� ����
    private Vector3 _direction;
    float dir;
    Transform hitTrans;
    public bool root = false;
    //---------------------------------------------------------------------

    public Vector3 DirFromAngle(float angleInDegrees)
    {
        angleInDegrees += dog.transform.eulerAngles.y;

        return new Vector3(Mathf.Sin(angleInDegrees * Mathf.Deg2Rad), 0, Mathf.Cos(angleInDegrees * Mathf.Deg2Rad));
    }

    //��ֹ� ã��(2)
    //private void find()
    //{
    //    Vector3 leftBoundary = DirFromAngle(-ViewAngle2 / 2);
    //    Vector3 rightBoundary = DirFromAngle(ViewAngle2 / 2);

    //    if (state != State.follow)
    //    {
    //        Debug.DrawLine(dog.transform.position, dog.transform.position + leftBoundary, Color.blue);
    //        Debug.DrawLine(dog.transform.position, dog.transform.position + rightBoundary, Color.red);

    //        if (Physics.Raycast(dog.transform.position , dog.transform.forward, out hit, ViewDistance))
    //        {
    //            _direction = (hit.transform.position - dog.transform.position).normalized;

    //            float _angle = Vector3.Angle(_direction, dog.transform.forward);
    //            if (hit.collider.tag == "obstacle")
    //            {
    //                if (_angle < ViewAngle2 * 0.5f)
    //                {
    //                    dir = Vector3.Distance(hit.transform.position, dog.transform.position);
    //                    if (dir < 10)
    //                    {
    //                        if (!downcheck)
    //                        {
    //                            Guide.SetActive(true);
    //                            state = State.run;
    //                        }
    //                    }
    //                }

    //            }

    //            //if (hit.collider.tag == "Player")
    //            //{
    //            //    if (_angle < ViewAngle2 * 0.5f)
    //            //    {
    //            //        agent.enabled = false;
    //            //        Vector3 vex = new Vector3(character.transform.position.x-3f, dog.transform.position.y, character.transform.position.z);
    //            //        dog.transform.position = Vector3.Lerp(dog.transform.position,vex,Time.deltaTime * runSpeed);
    //            //    }

    //            //}
    //        } //ray

    //        if (Physics.Raycast(dog.transform.position - dog.transform.forward, _direction, out hit, ViewDistance))
    //        {
    //            Debug.DrawLine(dog.transform.position, dog.transform.position - leftBoundary, Color.blue);
    //            Debug.DrawLine(dog.transform.position, dog.transform.position - rightBoundary, Color.red);

    //            if (hit.collider.tag == "Player")
    //            {
    //                float _angle = Vector3.Angle(_direction, -dog.transform.forward);

    //                if (_angle < ViewAngle2 * 0.5f)
    //                {
    //                    agent.enabled = false;
    //                    Vector3 vex = new Vector3(character.transform.position.x - 3f, dog.transform.position.y, character.transform.position.z);
    //                    dog.transform.position = Vector3.Lerp(dog.transform.position, vex, Time.deltaTime * runSpeed);
    //                }

    //                dir = Vector3.Distance(hit.transform.position, dog.transform.position);

    //                if (dir > 5f)
    //                {
    //                    state = State.walk;
    //                }
    //            }
    //        }
    //    }
    //}

    //��ֹ� ã��(1) - ����
    
    #region
    private void FindVisibleTargets()
    {
        Vector3 leftBoundary = DirFromAngle(-ViewAngle / 2);
        Vector3 rightBoundary = DirFromAngle(ViewAngle / 2);
        Collider[] targets = Physics.OverlapSphere(dog.transform.position, ViewDistance, ObstacleMask);

        if (state != State.follow)
        {
            for (int i = 0; i < targets.Length; i++)
            {
                _direction = (targets[i].transform.position - dog.transform.position).normalized;

                float _angle = Vector3.Angle(_direction, dog.transform.forward);

                Debug.DrawLine(dog.transform.position, dog.transform.position + leftBoundary, Color.blue);
                Debug.DrawLine(dog.transform.position, dog.transform.position + rightBoundary, Color.red);

                if (Physics.Raycast(dog.transform.position + dog.transform.forward, _direction, out hit, ViewDistance))
                {
                    if (hit.collider.tag == "obstacle" && targets[i].tag == "obstacle")
                    {
                        hitTrans = targets[i].transform;
                        if (_angle < ViewAngle * 0.5f)
                        {
                            dir = Vector3.Distance(hitTrans.position, dog.transform.position);
                            if (dir < 10)
                            {
                                if (!downcheck)
                                {
                                    Guide.SetActive(true);
                                    state = State.run;
                                }
                            }
                        }//angle
                    } //tag

                    #region
                    if (hit.collider.tag == "Player" && targets[i].tag == "Player")
                    {
                        hitTrans = targets[i].transform;

                        if (_angle < ViewAngle * 0.5f)
                        {
                            agent.ResetPath();
                            agent.SetDestination(hitTrans.position + hitTrans.forward);
                        }
                    }
                    #endregion

                } //ray

            }
        }

    }

    #endregion

    //reset ����
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.tag == "Goal")
        {
            agent.isStopped = true;
        }
    }
}
