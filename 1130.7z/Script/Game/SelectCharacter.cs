using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class SelectCharacter : MonoBehaviour
{
    public GameObject slot0, slot1, slot2, slot3;
    public GameObject sel, walkGame;

    public GameObject woman, man, animal1, animal2;
    public GameObject cam;

    public GameObject Re_ha;

    //���� ��
    public GameObject character, pet;

    //���� ��ġ ����

    Animator animator;

    //save
    private SaveData_Game gameData = new SaveData_Game();
    private string loadgame, ingameName, characterName_walk, petName;

    void load()
    {
        loadgame = File.ReadAllText(Application.dataPath + "/Resources/gameData.json");
        gameData = JsonUtility.FromJson<SaveData_Game>(loadgame);


        for (int i = 0; i < gameData.ingameName.Count; i++)
        {
            if(gameData.ingameName.Count != 1)
            {
                i = gameData.ingameName.Count-1;
                if (gameData.ingameName[i] == "In Game Walk" && !walkGame.activeSelf)
                {
                    ingameName = gameData.ingameName[i];
                }

                if (gameData.ingameName[i] == "In Game Model")
                {
                    ingameName = gameData.ingameName[i];
                }
            }
            else
            {
                if (gameData.ingameName[i] == "In Game Walk" && !walkGame.activeSelf)
                {
                    ingameName = gameData.ingameName[i];
                }

                if (gameData.ingameName[i] == "In Game Model")
                {
                    ingameName = gameData.ingameName[i];
                }
            }
        }

        for (int i = 0; i < gameData.characterName_walk.Count; i++)
        {
            if (gameData.characterName_walk.Count != 1)
            {
                i = gameData.characterName_walk.Count-1;
                //Debug.Log(i);
                characterName_walk = gameData.characterName_walk[i];
            }
            else
            {
                characterName_walk = gameData.characterName_walk[i];
            }
        }

        for (int i = 0; i < gameData.petName.Count; i++)
        {
            if (gameData.petName.Count != 1)
            {
                i = gameData.petName.Count-1;

                petName = gameData.petName[i];
            }

            else
            {
                petName = gameData.petName[i];
            }
        }
    }

    public void check()
    {
        load();

        if (ingameName == "In Game Walk")
        {
            if (characterName_walk == null)
            {
                character = woman;
            }

            if(characterName_walk != null)
            {
                if (characterName_walk == "woman")
                {
                    character = woman;
                    slot0.SetActive(true);
                    slot1.SetActive(false);
                }

                if (characterName_walk == "man")
                {
                    character = man;
                    slot0.SetActive(false);
                    slot1.SetActive(true);
                }
            }

            if (petName == null)
            {
                pet = animal1;
            }
            if (petName != null)
            {
                pet = animal1;
            }

            character.SetActive(true);

            pet.SetActive(true);

            if (Re_ha.activeSelf)
            {
                Re_ha.SetActive(false);
            }

        }

        if (ingameName == "In Game Model")
        {
            character = Re_ha;
            animator = character.GetComponent<Animator>();

            character.SetActive(true);
            animator.Play("Idle");

            if (woman.activeSelf || man.activeSelf)
            {
                woman.SetActive(false);
                man.SetActive(false);
            }
        }

        cam.SetActive(true);
    }

    int num;

    public void next()
    {
        //num = gameData.NextNum;
        //gameData.NextNum ++;

        if(ingameName == "In Game Walk")
        {
            save(1);
        }
        save(0);
    }

    void save(int i)
    {
        switch (i)
        {
            case 0:
                if(ingameName == "In Game Walk")
                {
                    gameData.characterName_walk.Add(character.name);
                }
                if(ingameName == "In Game Model")
                {
                    gameData.characterName_model.Add(character.name);
                }
                break;

            case 1:
                gameData.petName.Add(pet.name);
                break;
        }

        string gameJs = JsonUtility.ToJson(gameData);
        File.WriteAllText(Application.dataPath + "/Resources/gameData.json", gameJs);

    }


    private void Start()
    {
        check();
    }

    public void back()
    {
        character.SetActive(false);
        cam.SetActive(false);

        if (ingameName == "In Game Walk")
        {
            pet.SetActive(false);
            save(0);
            save(1);
        }

        if (ingameName == "In Game Model")
        {
            save(0);
        }
    }

    //���� ���� - ����
    public void onSlot(int i)
    {
        load();

        switch (i)
        {
            case 0:
                slot0.SetActive(true);
                slot1.SetActive(false);

                if (ingameName == "In Game Walk")
                {
                    character = woman;
                    man.SetActive(false);
                }

                character.SetActive(true);
                break;

            case 1:
                slot1.SetActive(true);
                slot0.SetActive(false);

                if (ingameName == "In Game Walk")
                {
                    character = man;
                    woman.SetActive(false);
                }

                character.SetActive(true);
                break;

            // ĳ����(���, ����)

            case 2:
                slot2.SetActive(true);
                slot3.SetActive(false);

                if (ingameName == "In Game Walk")
                {
                    pet = animal1;
                }

                pet.SetActive(true);
                break;

            case 3:
                slot3.SetActive(true);
                slot2.SetActive(false);

                if (ingameName == "In Game Walk")
                {
                    pet = animal2;
                }

                pet.SetActive(true);
                break;
        }
    }

}
