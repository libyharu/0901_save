using System.Collections;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;

public class Test : MonoBehaviour
{
    private int level;
    public Rigidbody dogRigidbody;

    public GameObject dog, character, WalkGame, popup;

    public Transform ST1;

    private Vector3 direction;  // ����

    // ���� ����
    [SerializeField] private bool isWalking; // �ȴ���, �� �ȴ��� �Ǻ�
    [SerializeField] private bool isFollow;// �ҷ�����
    private float walkTime = 5f;  // �ȱ� �ð�
    private float walkSpeed, runSpeed;  // �ȱ� �ӷ�
    [SerializeField] private bool israndom;

    [SerializeField] private float currentTime;
    [SerializeField] private bool isAction;  // �ൿ ������ �ƴ��� �Ǻ�
    private float waitTime = 2f;

    public GameObject Guide;

    float max_speed;
    public Animation ani;
    public RaycastHit hit;

    public Transform target;
    public NavMeshAgent agent;
    [SerializeField] private bool isrunning;


    public void dogging()
    {
        //level = GameObject.Find("SceneManager").GetComponent<SceneManager>().level;
        //popup = GameObject.Find("SceneManager").GetComponent<SceneManager>().popup;
        //dog = GameObject.Find("Character Selection").GetComponent<SelectCharacter>().pet;
        //character = GameObject.Find("Character Selection").GetComponent<SelectCharacter>().character;
        //GameObject.Find("GameManager").GetComponent<DogControl>().enabled = true;


        //dog.SetActive(true);
        if (popup.name == "Pop Up1")
        {
            if (dog.activeSelf)
            {
                agent = dog.GetComponent<NavMeshAgent>();
                dogRigidbody = dog.GetComponent<Rigidbody>();
                dogRigidbody.useGravity = true;

                Level(level);

                Guide.SetActive(false);
                currentTime = waitTime;
                isAction = true;   // ��⵵ �ൿ

                direction.Set(0f, 180f, 0f);
                dog.transform.position = ST1.transform.position;
            }
        }

    }

    void Level(int level)
    {
        if (level == 1)
        {
            max_speed = 4f;
        }
        else if (level == 2)
        {
            max_speed = 2f;
        }
        else if (level == 3)
        {
            max_speed = 3f;
        }
        walkSpeed = max_speed;
        runSpeed = max_speed * 1.5f;
    }

    void Update()
    {
        if (WalkGame.activeSelf)
        {
            float dis = Vector3.Distance(character.transform.position, dog.transform.position);

            if (dis < 5)
            {
                agent.speed = runSpeed;
                isFollow = false;
            }
            if (dis >= 5)
            {
                agent.speed = walkSpeed;
            }


            if (popup.activeSelf)
            {
                agent.enabled = false;
                dog.SetActive(false);
            }
        }
    }

    void FixedUpdate()
    {
        if (WalkGame.activeSelf)
        {

            following();
            FindVisibleTargets();
        }
    }

    private void Move()
    {
        if (isWalking)
        {
            agent.enabled = false;

            agent.enabled = true;

            agent.SetDestination(target.position);

        }

        if (!isWalking)
        {
            agent.enabled = false;
        }
    }

    private void ElapseTime()
    {
        if (isAction)
        {
            currentTime -= Time.deltaTime;

            if (currentTime <= 0)
            {
                isAction = true;
                TryWalk();

                currentTime = 10f;

                if (israndom)
                {
                    direction.Set(0f, Random.Range(130f, 210f), 0f);
                    int _random = Random.Range(0, 5);

                    Debug.Log("random: " + _random);

                    if (_random <= 3) { TryWalk(); }
                    else if (_random > 3) { Wait(); }
                    israndom = false;
                }
            }
        }
    }

    private void Wait()
    {
        currentTime = waitTime;

    }

    private void TryWalk()  // �ȱ�
    {
        currentTime = walkTime;
        isWalking = true;
    }


    private void OnGUI()
    {
        Event e = Event.current;
        if (e.isKey)
        {
            if (Input.anyKeyDown)
            {
                if (e.keyCode == KeyCode.UpArrow)
                {
                    isWalking = true;
                }
                if (e.keyCode == KeyCode.DownArrow)
                {
                    if (Guide.activeSelf == true)
                    {
                        isFollow = true;
                        downcheck = true;
                    }
                }
            }

            if (e.type == EventType.KeyUp)
            {
                if (e.keyCode == KeyCode.UpArrow)
                {
                    isWalking = false;
                }

            }
        }
    }

    private void following()
    {
        if (isFollow)
        {
            isrunning = false;
            isWalking = false;

            Guide.SetActive(false);

            walkSpeed = runSpeed;

            dogRigidbody.MovePosition(dog.transform.position - dog.transform.forward * Time.deltaTime);
        }

        if (!isFollow)
        {
            walkSpeed = max_speed;
            isWalking = true;
        }
    }

   
    [SerializeField] private bool downcheck;

    ///
    private float ViewAngle = 230;    //�þ߰�
    private float ViewDistance = 45; //�þ߰Ÿ�

    public LayerMask ObstacleMask;  //Obstacle ���̾��ũ ���� ���� ����
    private Vector3 _direction;
    //private Vector3 targetpos;
    float dir;
    Transform hitTrans;

    public Vector3 DirFromAngle(float angleInDegrees)
    {
        angleInDegrees += dog.transform.eulerAngles.y;

        return new Vector3(Mathf.Sin(angleInDegrees * Mathf.Deg2Rad), 0, Mathf.Cos(angleInDegrees * Mathf.Deg2Rad));
    }

    //��ֹ� ã��
    private void FindVisibleTargets()
    {
        Vector3 leftBoundary = DirFromAngle(-ViewAngle / 2);
        Vector3 rightBoundary = DirFromAngle(ViewAngle / 2);


        Collider[] targets = Physics.OverlapSphere(dog.transform.position, ViewDistance, ObstacleMask);


        for (int i = 0; i < targets.Length; i++)
        {
            _direction = (targets[i].transform.position - dog.transform.position).normalized;

            float _angle = Vector3.Angle(_direction, dog.transform.forward);

            Debug.DrawLine(dog.transform.position, dog.transform.position + leftBoundary, Color.blue);
            Debug.DrawLine(dog.transform.position, dog.transform.position + rightBoundary, Color.red);

            if (Physics.Raycast(dog.transform.position + dog.transform.forward, _direction, out hit, ViewDistance))
            {
                if (hit.collider.tag == "Fence")
                {
                    if (targets[i].tag == "Fence")
                    {
                        hitTrans = targets[i].transform;
                        //targetpos = new Vector3(hit.collider.transform.position.x, transform.position.y, hit.collider.transform.position.z);

                        if (_angle < ViewAngle * 0.5f)
                        {
                            dir = Vector3.Distance(hitTrans.position, dog.transform.position);
                            if (dir < 15 && !downcheck)
                            {
                                Guide.SetActive(true);

                                isrunning = true;
                                if (isrunning)
                                {
                                    dog.transform.position = Vector3.Lerp(dog.transform.position, hitTrans.position, Time.deltaTime * 0.5f);
                                    dog.transform.LookAt(hitTrans);

                                }
                            }
                        }
                        //dog.transform.LookAt(dog.transform.forward);
                        if (hitTrans.position.z >= dog.transform.position.z)
                        {
                            downcheck = false;
                        }
                    }
                }
                if (hit.collider.tag != "Player")
                {
                    if (targets[i].tag != "Player")
                    {
                        ElapseTime();
                        Move();
                    }
                }

                if (hit.collider.tag == "Player")
                {
                    Debug.Log("none" + hit.collider.tag);

                    Vector3 vc = new Vector3(character.transform.position.x, dog.transform.position.y, character.transform.position.z - 3f);

                    dog.transform.position = vc;

                }
            }

        }

    }
}
