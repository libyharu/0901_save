using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;
public class Walking : MonoBehaviour
{
    /*
    //üũ
    public bool WalkingTimer, CheckWalk;

    #region �����̵�, Ÿ�̸�
    public Slider slider;
    public float time;
    public Text clockT;
    string clockText;
    #endregion

    #region ĳ����, ī�޶�, ����, ��, �˾� ��
    public GameObject WalkCamera, walkGame;

    public GameObject plane1, inplane;
    public GameObject goal;

    public GameObject Character;
    public GameObject woman, man;
    public GameObject popup;
    #endregion

    public Image[] img;
    private Color color, color2;
    private int j, level;

    private SaveData_Game gameData = new SaveData_Game();
    private string loadgame;
    private string characterName_walk;

    public Text txt;
    private Vector3 pos, pos2;
    public GameObject obs, folder;
    private float timer;

    void test()
    {
        float randomX = Random.Range(Character.transform.position.x - 8f, Character.transform.position.x + 8f);
        float randomZ = Character.transform.position.z - 10f;

        timer -= Time.deltaTime;

        if (timer <= 0.0f)
        {
            GameObject obj = (GameObject)Instantiate(obs, new Vector3(randomX, Character.transform.position.y, randomZ), Quaternion.identity);
            obj.transform.parent = folder.transform;
            timer = 10f;
        }
    }


    public void Start()
    {
        daum();
        Animator a = Character.GetComponent<Animator>();
        pos = Character.transform.position;
    }


    public void ingame_Pause()
    {
        popup.SetActive(true);
        Time.timeScale = 0;
        pos2 = Character.transform.position;

        gameData.isReset_w = false;
        save();
    }

    public void Load()
    {
        loadgame = File.ReadAllText(Application.dataPath + "/Resources/gameData.json");
        gameData = JsonUtility.FromJson<SaveData_Game>(loadgame);

        Character = woman;
        CheckWalk = gameData.isWalking;

        for (int i = 0; i < gameData.level.Count; i++)
        {
            level = gameData.level[i];
        }
        for (int i = 0; i < gameData.characterName_walk.Count; i++)
        {
            characterName_walk = gameData.characterName_walk[i];
        }
    }

    void save()
    {
        string json = JsonUtility.ToJson(gameData);
        File.WriteAllText(Application.persistentDataPath + "/infoData.json", json);
    }

    public void daum()
    {
        Load();

        if (characterName_walk == "woman")
        {
            Character = woman;
        }
        if (characterName_walk == "man")
        {
            Character = man;
        }

        levelCheck(level);
        time = 0;
    }

    void levelCheck(int level)
    {
        if (level <= 0)
        {
            level = 1;
        }
        switch (level)
        {
            case 1:
                inplane = plane1;
                break;

            case 2:
                inplane = plane1;
                break;

            case 3:
                inplane = plane1;
                break;
        }
        slider.maxValue = Vector3.Distance(Character.transform.position, goal.transform.position); ;
        slider.value = 0;

        Character.SetActive(true);
    }

    //OnGui
    public void OnGUI()
    {
        Event e = Event.current;

        if (!Input.anyKey)
        {
            j = 4;
            colorchange(0);
        }

        #region         //Ű�� ���� - memo
        if (Input.anyKey)
        {
            j = 4;
            colorchange(1);

            if (e.isKey)
            {
                if (e.keyCode == KeyCode.UpArrow)
                {
                    j = 0;

                    if (e.type == EventType.KeyDown)
                    {
                        colorchange(0);
                    }
                    if (e.type == EventType.KeyUp)
                    {
                        colorchange(1);
                    }
                }
                else if (e.keyCode == KeyCode.LeftArrow)
                {
                    j = 1;
                    if (e.type == EventType.KeyDown)
                    {
                        colorchange(0);
                    }
                    if (e.type == EventType.KeyUp)
                    {
                        colorchange(1);
                    }
                }
                else if (e.keyCode == KeyCode.RightArrow)
                {
                    j = 2;
                    if (e.type == EventType.KeyDown)
                    {
                        colorchange(0);
                    }
                    if (e.type == EventType.KeyUp)
                    {
                        colorchange(1);
                    }
                }
                else if (e.keyCode == KeyCode.DownArrow)
                {
                    j = 3;
                    if (e.type == EventType.KeyDown)
                    {
                        colorchange(0);
                    }
                    if (e.type == EventType.KeyUp)
                    {
                        colorchange(1);
                    }
                }
            }
        }
        #endregion
    }

    //���� �ٲٴ� ��
    void colorchange(int i)
    {
        Color color;
        switch (i)
        {
            case 0:
                color = img[j].color;
                color = new Color(1, 1, 0);
                color.a = 1f;
                img[j].color = color;
                break;

            case 1:
                color = img[j].color;
                color = new Color(1, 1, 1);
                color.a = 0.4f;
                img[j].color = color;
                break;
        }
    }

    private Vector3 destination;
    void posCheck()
    {
        destination = goal.transform.position;

        pos2 = Character.transform.position;

        float dis = Vector3.Distance(Character.transform.position, destination);

        if (dis <= 1.5f)
        {
            Load();
            float posMinus = Vector3.Distance(pos, pos2);
            txt.text = "�̵��Ÿ�: " + posMinus.ToString();

            gameData.isReset_w = true;
            popup.SetActive(true);
            save();
        }
    }

    private void Update()
    {
        test();

        //Ÿ�̸�
        time += Time.deltaTime;
        clockText = ((int)time / 60 % 60).ToString();
        clockT.text = clockText + " : " + ((int)time % 60).ToString();

        if (Character != null)
        {
            float dis = Vector3.Distance(Character.transform.position, goal.transform.position);
            slider.value = slider.maxValue - dis;
        }

        posCheck();
    }
    */
}
