using UnityEngine;
using UnityEngine.UI;

public class SelectGame : MonoBehaviour
{
    //highlight
    public GameObject highlight1, highlight2, highlight3;


    void Start()
    {
        highlight1.SetActive(false);

    }

    public void EnterHighlight(int i)
    {
        switch (i)
        {
            case 0:
                highlight1.SetActive(true);
                break;
            case 1:
                highlight2.SetActive(true);
                break;
            case 2:
                highlight3.SetActive(true);
                break;
        }
    }


    public void OutHighlight(int i)
    {
        switch (i)
        {
            case 0:
                highlight1.SetActive(false);
                break;
            case 1:
                highlight2.SetActive(false);
                break;
            case 2:
                highlight3.SetActive(false);
                break;
        }
    }

}
