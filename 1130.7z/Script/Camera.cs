using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
public class Camera : MonoBehaviour
{
    // ī�޶� ����
    public GameObject cam, walkGame;
    public Transform man, woman;
    Transform hair;
    private float distance = 3.5f;

    [SerializeField] private float rotationDamping = 50f;

    private SaveData_Game gameData = new SaveData_Game();
    private string loadgame;

    private void Start()
    {
        load();
    }

    private void Update()
    {
        camRot();
    }

    public void load()
    {
        loadgame = File.ReadAllText(Application.dataPath + "/Resources/gameData.json");
        gameData = JsonUtility.FromJson<SaveData_Game>(loadgame);

        hair = woman;
        for (int i = 0; i < gameData.characterName_walk.Count; i++)
        {
            if (gameData.characterName_walk.Count != 1)
            {
                i = gameData.characterName_walk.Count-1;

                if (gameData.characterName_walk[i] == "man")
                {
                    hair = man;
                }

                if (gameData.characterName_walk[i] == "woman")
                {
                    hair = woman;
                }
            }

            else
            {
                if (gameData.characterName_walk[i] == "man")
                {
                    hair = man;
                }

                if (gameData.characterName_walk[i] == "woman")
                {
                    hair = woman;
                }
            }

        }
    }

    void camRot()
    {

        float currAngleY = transform.eulerAngles.y;

        float targetAngleY = hair.eulerAngles.y;

        //float camRotaX = transform.eulerAngles.x;

        currAngleY = Mathf.LerpAngle(currAngleY, targetAngleY, rotationDamping * Time.deltaTime);

        Vector3 dir = (hair.position - cam.transform.position).normalized;
        cam.transform.position = hair.position;
        Quaternion lookRotation = Quaternion.LookRotation(dir);

        lookRotation = Quaternion.Euler(0, currAngleY, 0);
        transform.position -= lookRotation * Vector3.forward * distance;


        transform.LookAt(hair);
    }
    

}
