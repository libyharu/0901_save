using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;

public class LoginPage : MonoBehaviour
{
    public GameObject icon;

    private GameObject menu, login;

    public Text guideTxt;

    private string guide;

    public InputField id, pass;

    public bool check;

    private SaveData_Info infoData = new SaveData_Info();
    void save()
    {
        infoData.isCheck = check;

        // ���� ��ü ����
        string json = JsonUtility.ToJson(infoData); // ���̽�ȭ
        File.WriteAllText(Application.dataPath + "/Resources/infoData.json", json);

    }

    private string loadJson, ingameName;

    public void open()
    {
        load();
        infoData.login = false;
        save();

        if (!check)
        {
            icon.SetActive(false);
            id.text = null;
            pass.text = null;
        }
        else if (check)
        {
            icon.SetActive(true);
            pass.text = null;

        }
    }

    private void load()
    {
        loadJson = File.ReadAllText(Application.dataPath + "/Resources/infoData.json");
        infoData = JsonUtility.FromJson<SaveData_Info>(loadJson);

        for (int i = 0; i < infoData.id.Count; i++)
        {
            id.text = infoData.id[i];
        }

        for (int i = 0; i < infoData.pass.Count; i++)
        {
            pass.text = infoData.pass[i];
        }

        check = infoData.isCheck;
    }

    private string c, d;

    //�α��� ��ư
    public void loginPage()
    {
        if (string.IsNullOrEmpty(id.text))
        {
            guide = "���̵� �Է��� �ּ���.";
            guideTxt.text = guide;
        }
        else if(string.IsNullOrEmpty(pass.text))
        {
            guide = "��й�ȣ�� �Է��� �ּ���.";
            guideTxt.text = guide;
        }

        //-----------------------

        if (!string.IsNullOrEmpty(id.text) && !string.IsNullOrEmpty(pass.text))
        {
            c = id.text;
            d = pass.text;

            if (infoData.id.Contains(c) && infoData.pass.Contains(d))
            {
                // �� ��ȣ�� ���ٸ�
                int idx = infoData.id.FindIndex(a => a.Contains(c));
                int idx2 = infoData.pass.FindIndex(a => a.Contains(d));

                if(idx == idx2)
                {
                    //�α���
                    infoData.login = true;
                    Debug.Log("login");
                }

                if (idx != idx2)
                {
                    guide = "���̵� ��й�ȣ�� Ȯ���� �ּ���.";
                    guideTxt.text = guide;
                }
            }
            else
            {
                guide = "��ġ���� �ʽ��ϴ�.";
                guideTxt.text = guide;
            }
        }

    }

    public void Newmemeber()
    {
        c = id.text;
        d = pass.text;

        if (infoData.id.Contains(c))
        {
            guide = "�����ϴ� ���̵�.";
            guideTxt.text = guide;
        }

        if (infoData.pass.Contains(d))
        {
            guide = "�����ϴ� ���.";
            guideTxt.text = guide;
        }

        if (!infoData.id.Contains(c) && !infoData.pass.Contains(d))
        {
            Debug.Log("ȸ�� ����");
            infoData.id.Add(id.text);
            infoData.pass.Add(pass.text);
            save();
        }
    }

    public void find()
    {
        Debug.Log("ID/PW ã��");
    }

    public void checkBox()
    {
        if (icon.activeSelf == true)
        {
            icon.SetActive(false);
            check = false;
        }
        else if(icon.activeSelf == false)
        {
            icon.SetActive(true);
            check = true;
        }

    }

}
